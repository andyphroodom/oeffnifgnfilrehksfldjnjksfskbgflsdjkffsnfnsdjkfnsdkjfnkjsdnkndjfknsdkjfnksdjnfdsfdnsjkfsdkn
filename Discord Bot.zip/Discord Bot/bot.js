const botconfig = require("./botconfig.json");
const tokenfile = require("./token.json");
const Discord = require("discord.js");
const Jimp = require(`jimp`)
const discord = require ('discord.js');
const fs = require("fs");
const bot = new Discord.Client();
bot.commands = new Discord.Collection();
let purple = botconfig.purple;
let cooldown = new Set();
let cdseconds = 5;


fs.readdir("./commands/", (err, files) => {

  if(err) console.log(err);
  let jsfile = files.filter(f => f.split(".").pop() === "js");
  if(jsfile.length <= 0){
    console.log("Couldn't find commands.");
    return;
  }

  jsfile.forEach((f, i) =>{
    let props = require(`./commands/${f}`);
    console.log(`${f} loaded!`);
    bot.commands.set(props.help.name, props);
  });
});

function changing_status() {
    let status = [`${bot.users.size} Users!`, '!help', `${bot.guilds.size} Servers!`]
    let random = status[Math.floor(Math.random() * status.length)]
    bot.user.setActivity(random)
}

bot.on("ready", () => {
    console.log("ZgarBot is ready! to be used ;-;");
    setInterval(changing_status, 3000);
})


bot.on("message", async message => {
  if(message.author.bot) return;
  if(message.channel.type === "dm") return;

  let prefix = botconfig.prefix;
  let messageArray = message.content.split(" ");
  let cmd = messageArray[0];
  let args = messageArray.slice(1);
  let commandfile = bot.commands.get(cmd.slice(prefix.length));
  if(commandfile) commandfile.run(bot,message,args);

});

exports.run = (client, message, args, tools) => {
    
    // Form Embed
    const embed = new Discord.MessageEmbed()
        .setColor(0xffffff);
    
    // Check if they entered a number between 0-10000
    if (isNaN(args[0]) || args[0] > 9999 || args[0] < 1) { // Run if out of parameters
        
        // Update embed footer
        embed.setFooter('Sorry, please enter a valid discrim.');
        
        // Send error message
        return message.channel.send(embed);
        
    }
    
   // Initialize response string
   let resp = '';
   
   // Go through each user connected to the bot
   client.users.map(function(user) {
       
       // The if statement will check if the input is equal to the user's discrim
       if (user.discriminator == args[0]) return resp += `${user.username}\n`;
       else return; // If not, return
       
   })
   
    // Add embed options
    embed.setTitle(`Discrim: ${args[0]}`)
        .setDescription(resp);
        
    // Send Embed
    message.channel.send(embed)
    
}

    
bot.on('guildMemberAdd', member => {
let logChannel = member.guild.channels.find('name', '⟬💾⟭➞logs');

  let logEmbed = new Discord.RichEmbed()
  .setAuthor("BCore | Logs") 
  .setDescription(member.user.username + " has `` entered`` in the server. (" + member.user.id + ")")
  .setColor('RANDOM')
  .setFooter("The player joined", member.user.displayAvatarURL)
  .setTimestamp()
  logChannel.send(logEmbed);
})
bot.on('guildMemberRemove', member => {
let logChannel = member.guild.channels.find('name', '⟬💾⟭➞logs');

  let logEmbed = new Discord.RichEmbed()
  .setAuthor("BCore | Logs") 
    .setDescription(member.user.username + " has `` left '' the server. (" + member.user.id + ")")
  .setFooter("The player left off", member.user.displayAvatarURL)
  .setColor('RANDOM')
  .setTimestamp()
  logChannel.send(logEmbed);
})



bot.login(tokenfile.token);