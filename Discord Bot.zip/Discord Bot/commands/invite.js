const Discord = module.require('discord.js');

module.exports.run = async (bot, message, args, prefix) => {

    message.channel.send("https://discordapp.com/oauth2/authorize?client_id=544275076913168415&scope=bot&permissions=8");

}

module.exports.help = {
    name: "invite"
}