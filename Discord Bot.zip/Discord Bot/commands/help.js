const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
.addField("BioBots Service",["Here are all the Commands"],true)
    .setColor("#00990f")
    .setThumbnail(sicon)
.addField("!kick",["kicks the user  you mention"],true)
.addField("!ban",[" bans the user you mention"],true)
.addField("!report",["sends a report for a user."],true)
.addField("!tempmute",["mutes a user."],true)
.addField("!link",["makes an invite for this server"],true)
.addField("!invite",["sends you the invite for the bot."],true)
.addField("!servers",["shows what servers the bot is in."],true)
.addField("!love",["love meter."],true)
.addField("!hug",["hugs a user."],true)
.addField("kiss",["kisses a user."],true)
.addField("!cuddle",["cuddles a user."],true)
.addField("!slap",["slaps a user."],true)
.addField("!punch",["punches a user"],true)
.addField("!ping",["gets the ping for the bot"],true)
.addField("!clear",["clears the messages"],true)
.addField("!ascii",["makes the text ascii"],true)
.addField("!remindme",["sets a reminder"],true)
.addField("!say",["bot repeats"],true)
.addField("!prefix",["changes the bot prefix"],true)
.addField("!addrole",["gives the user the role"],true)
.addField("!porn",["Only Work In NFSW Channel"],true)
.addField("!8ball",["Ask it anything"],true)
.addField("!meme",["Gets a funny meme"],true)
    
    
.addField("More commands comming soon.",["Bot Made By Mage and Gaut"],true)

    message.channel.send(serverembed);
}

module.exports.help = {
  name:"help"
}