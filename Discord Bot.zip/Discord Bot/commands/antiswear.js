    bot.on("message", async message => {
        if (message.author.bot) return
        let modlogid = 12345678912345 //Channel ID for Mod Log
        let modlog = message.guild.channels.get(modlogid)
        const profanities = require('profanities');
        let profEmbed = new Discord.RichEmbed()
            .setDescription(`User ${message.author}, has been caught swearing!\nUserID: ${message.author.id} - UserTag: ${message.author.tag}`)
        for (x = 0; x < profanities.length; x++) {
            if (message.content.toUpperCase() == profanities[x].toUpperCase()) {
                // if (message.content == profanities)
                message.author.send(`Hinami Security, Swearing is not allowed here. Please refrain from swearing, ${message.author}`)
                modlog.send(profEmbed).catch(() => message.guild.owner(`Mod-log hasn't been configured, any discord profanity triggers will be sent directly to you.\n\`${message.content}\`\nBy User: ${message.author}\nBy UID: ${message.author.id}\nBy UserTag: ${message.author.tag}`))
                modlog.send(`\`Message Sent\`: ${message.content}`)
                message.delete();
                return;
            }
        }
    })